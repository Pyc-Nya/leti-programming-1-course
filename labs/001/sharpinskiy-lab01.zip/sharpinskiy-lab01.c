#include<stdio.h>

int main() {

    int n, digit, globalCounter, counter, maxS, last, i;
    globalCounter = maxS = 0;
    counter = 1;

    printf("Enter the number of digits: ");
    scanf("%d", &n);
    printf("\n");

    printf("Enter digit (%d numbers left): ", n);
    scanf("%d", &last);
    printf("\n");

    n--;

    for (i=0; i < n; i++) {
        printf("Enter digit (%d numbers left): ", n-i);
        scanf("%d", &digit);
        printf("\n");
        if (digit < last) {
            if (counter > 1) {
                globalCounter++;
                if (maxS < counter) {
                    maxS = counter;
                }
            }
            counter = 1;
        } else {
            counter++;
        }
        last = digit;
    }

    if (counter > 1) {
        globalCounter++;
        if (maxS < counter) {
            maxS = counter;
        }
    }

    printf("Number of subsequences: %d", globalCounter);
    printf("\n");
    printf("Max length of subsequence: %d", maxS);
    printf("\n");


    return 0;
}
